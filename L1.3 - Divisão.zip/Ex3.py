def divisao(a,b):
    divisao1 = int(a)//int(b)
    divisao2 = int(a)/int(b)
    return print(f"{divisao1}\n\n{divisao2:.2f}")

input1 = input(" ")
input2 = input(" ")

resultado = divisao(input1,input2)