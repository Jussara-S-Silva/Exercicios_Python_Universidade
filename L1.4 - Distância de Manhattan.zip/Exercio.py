def distancia(x1, y1, x2, y2):
    saida = abs(x1 - x2) + abs(y1 - y2)
    return print(f"{saida:.4f}")

input1 = float(input(""))
input2 = float(input(""))
input3 = float(input(""))
input4 = float(input(""))

resultado = distancia(input1, input2, input3, input4)