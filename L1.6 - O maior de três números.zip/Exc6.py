def numeromaiordostres(x,y,z):
    maiornum1 = ((x+y)/2) + abs((x-y)/2)
    numeromaior = ((maiornum1+z)/2) + abs((maiornum1-z)/2)

    return print(f"O maior inteiro: {int(numeromaior)}")

input1 = int(input(""))
input2 = int(input(""))
input3 = int(input(""))

resultado = numeromaiordostres(input1,input2,input3)