def multiplicar(num1,num2):
    produto = int(num1)*int(num2)
    return produto

input1 = input("Por favor, insira o primeiro valor válido (número inteiro): ")
input2 = input("Por favor, insira o segundo valor válido (número inteiro): ")

resultado = multiplicar(input1,input2)
print("produto = {}".format(resultado))