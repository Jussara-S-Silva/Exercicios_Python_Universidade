def multiplicar(num1):
    produto = float(num1)*3
    return produto

input1 = float(input("Por favor, insira o primeiro valor válido (número real): "))


resultado = multiplicar(input1)


print("O triplo de %.2f" % input1,"é %.2f" % resultado)