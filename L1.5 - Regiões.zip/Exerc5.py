def totalregioes (x):
    Quantidadederegioes = ((x*(x+1))/2)+1
    return print(int(Quantidadederegioes))

input1 = int(input(""))

resultado = totalregioes(input1)